<?php 
$conn = mysqli_connect("localhost", "root", "", "pra_lsp");

$idpetugas = $_GET['idpetugas'];

mysqli_query($conn, "DELETE FROM admin WHERE idpetugas = '$idpetugas'");
mysqli_query($conn, "ALTER TABLE admin AUTO_INCREMENT = 0;");

header("location:data-admin.php");

?>