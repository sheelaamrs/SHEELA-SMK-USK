-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 27, 2022 at 02:56 PM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 8.0.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pra_lsp`
--

-- --------------------------------------------------------

--
-- Table structure for table `buku`
--

CREATE TABLE `buku` (
  `idbuku` int(11) NOT NULL,
  `idkategori` int(11) NOT NULL,
  `judul` varchar(128) NOT NULL,
  `pengarang` varchar(128) NOT NULL,
  `penerbit` varchar(128) NOT NULL,
  `deskripsi` varchar(512) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `buku`
--

INSERT INTO `buku` (`idbuku`, `idkategori`, `judul`, `pengarang`, `penerbit`, `deskripsi`) VALUES
(1, 2, 'Resep Mantab', 'Cheff Junaaa', 'SuciptoBook', 'Buku terbaik bagi pemula'),
(2, 1, 'Pemprograman Website', 'Sandhika Galih', 'Merah1Group', 'Kuasai Landing Page dalam 2 semester'),
(3, 4, 'Seribu Passing', 'Decuel', 'Bangkrutlona', 'Menang Tak Perlu... Seribu Passing No 1'),
(4, 1, 'Takeaway Laptop', 'Patan Odinson', 'CipinangPark', 'Takeaway Laptop dalam 5 detik');

-- --------------------------------------------------------

--
-- Table structure for table `detail_buku`
--

CREATE TABLE `detail_buku` (
  `iddetailbuku` int(11) NOT NULL,
  `idbuku` int(11) NOT NULL,
  `status` enum('Dipinjam','Ada') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `detail_buku`
--

INSERT INTO `detail_buku` (`iddetailbuku`, `idbuku`, `status`) VALUES
(1, 1, 'Ada'),
(2, 2, 'Ada'),
(3, 3, 'Ada'),
(4, 4, 'Ada');

--
-- Triggers `detail_buku`
--
DELIMITER $$
CREATE TRIGGER `hapus_buku` AFTER DELETE ON `detail_buku` FOR EACH ROW BEGIN DELETE FROM buku WHERE idbuku = OLD.idbuku; END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `detail_peminjaman`
--

CREATE TABLE `detail_peminjaman` (
  `iddetail_peminjaman` int(11) NOT NULL,
  `idpeminjaman` int(11) NOT NULL,
  `iddetailbuku` int(11) NOT NULL,
  `tgl_kembali` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Triggers `detail_peminjaman`
--
DELIMITER $$
CREATE TRIGGER `hapuspeminjam` AFTER INSERT ON `detail_peminjaman` FOR EACH ROW BEGIN DELETE FROM peminjaman WHERE idpeminjaman = NEW.idpeminjaman; END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `kategori`
--

CREATE TABLE `kategori` (
  `idkategori` int(11) NOT NULL,
  `kategori` varchar(128) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `kategori`
--

INSERT INTO `kategori` (`idkategori`, `kategori`) VALUES
(1, 'Pelajaran'),
(2, 'Masak'),
(4, 'Olahraga'),
(5, 'Film');

-- --------------------------------------------------------

--
-- Table structure for table `member`
--

CREATE TABLE `member` (
  `idmember` int(11) NOT NULL,
  `nama_member` varchar(50) NOT NULL,
  `tempat_lahir` varchar(50) NOT NULL,
  `tgl_lahir` date NOT NULL,
  `alamat` varchar(128) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `member`
--

INSERT INTO `member` (`idmember`, `nama_member`, `tempat_lahir`, `tgl_lahir`, `alamat`) VALUES
(1, 'Rizqi Pratama', 'DKI Jakarta', '2000-02-19', 'Jl. Jauh Dah'),
(2, 'Siti Maesaroh', 'Riyadh', '1945-08-17', 'Jl. Kejayaan'),
(3, 'Fulan Bin Fulan', 'Solo', '2008-04-14', 'Jl. Suka Duka'),
(4, 'Pablo Da Silvasss', 'Milan', '1910-01-01', 'Jl. As Roma');

-- --------------------------------------------------------

--
-- Table structure for table `peminjaman`
--

CREATE TABLE `peminjaman` (
  `idpeminjaman` int(11) NOT NULL,
  `idpetugas` int(11) NOT NULL,
  `idmember` int(11) NOT NULL,
  `idbuku` int(11) NOT NULL,
  `tgl_pinjam` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `petugas`
--

CREATE TABLE `petugas` (
  `idpetugas` int(11) NOT NULL,
  `nama_petugas` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(128) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `petugas`
--

INSERT INTO `petugas` (`idpetugas`, `nama_petugas`, `username`, `password`) VALUES
(1, 'Muhammad Faris Nauval', 'Faris', '$2y$10$4ml4nkUjfyFGUObxuxPrN.x0aK2UbpPARGuFGoe85luXiB2HxTaGi'),
(2, 'Muhammad Rayhan Hazami', 'rayhan', '$2y$10$j68AMh6vmRrqbmGBLkIqfej7i.2phdRhTwSP6DV2HsRc0UEluohPK'),
(3, 'Bang Haji', 'bangji', '$2y$10$cnqqYWfWhUTJNcigSIaHxutrCtlhC8jOjZPVOjFk21ow0XGyh1pZm'),
(4, 'dika', 'dika', '$2y$10$nvjQb.5aLY0s4o4Zzf9J.udhN3EEP.rWwbQjX9RAcQRrcyvLnHY7S');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `buku`
--
ALTER TABLE `buku`
  ADD PRIMARY KEY (`idbuku`),
  ADD KEY `idkategori` (`idkategori`);

--
-- Indexes for table `detail_buku`
--
ALTER TABLE `detail_buku`
  ADD PRIMARY KEY (`iddetailbuku`),
  ADD KEY `idbuku` (`idbuku`);

--
-- Indexes for table `detail_peminjaman`
--
ALTER TABLE `detail_peminjaman`
  ADD PRIMARY KEY (`iddetail_peminjaman`),
  ADD KEY `idpeminjaman` (`idpeminjaman`),
  ADD KEY `iddetailbuku` (`iddetailbuku`);

--
-- Indexes for table `kategori`
--
ALTER TABLE `kategori`
  ADD PRIMARY KEY (`idkategori`);

--
-- Indexes for table `member`
--
ALTER TABLE `member`
  ADD PRIMARY KEY (`idmember`);

--
-- Indexes for table `peminjaman`
--
ALTER TABLE `peminjaman`
  ADD PRIMARY KEY (`idpeminjaman`),
  ADD KEY `idmember` (`idmember`),
  ADD KEY `idpetugas` (`idpetugas`);

--
-- Indexes for table `petugas`
--
ALTER TABLE `petugas`
  ADD PRIMARY KEY (`idpetugas`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `buku`
--
ALTER TABLE `buku`
  MODIFY `idbuku` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `detail_buku`
--
ALTER TABLE `detail_buku`
  MODIFY `iddetailbuku` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `detail_peminjaman`
--
ALTER TABLE `detail_peminjaman`
  MODIFY `iddetail_peminjaman` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `kategori`
--
ALTER TABLE `kategori`
  MODIFY `idkategori` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `member`
--
ALTER TABLE `member`
  MODIFY `idmember` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `peminjaman`
--
ALTER TABLE `peminjaman`
  MODIFY `idpeminjaman` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `petugas`
--
ALTER TABLE `petugas`
  MODIFY `idpetugas` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `buku`
--
ALTER TABLE `buku`
  ADD CONSTRAINT `buku_ibfk_1` FOREIGN KEY (`idkategori`) REFERENCES `kategori` (`idkategori`);

--
-- Constraints for table `detail_buku`
--
ALTER TABLE `detail_buku`
  ADD CONSTRAINT `detail_buku_ibfk_1` FOREIGN KEY (`idbuku`) REFERENCES `buku` (`idbuku`);

--
-- Constraints for table `detail_peminjaman`
--
ALTER TABLE `detail_peminjaman`
  ADD CONSTRAINT `detail_peminjaman_ibfk_2` FOREIGN KEY (`iddetailbuku`) REFERENCES `detail_buku` (`iddetailbuku`);

--
-- Constraints for table `peminjaman`
--
ALTER TABLE `peminjaman`
  ADD CONSTRAINT `peminjaman_ibfk_1` FOREIGN KEY (`idpetugas`) REFERENCES `petugas` (`idpetugas`),
  ADD CONSTRAINT `peminjaman_ibfk_2` FOREIGN KEY (`idmember`) REFERENCES `member` (`idmember`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
