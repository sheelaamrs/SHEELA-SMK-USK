<?php
session_start();
$kon = mysqli_connect("localhost", "root", "", "pra_lsp");


require('../vendor/fpdf/fpdf.php');
$pdf = new FPDF('P', 'mm','Letter');

$pdf->AddPage();

$pdf->SetFont('Times','B',16);
$pdf->Cell(0,7,'LAPORAN PEMINJAMAN BUKU PERPUSTAKAAN DIGITAL',0,1,'C');

$pdf->Cell(10,7,'',0,1);

$pdf->SetFont('Times','B',12);
$pdf->MultiCell(0,12,"Tanggal Cek Laporan : ".date("d-m-Y"),'C');
$pdf->Cell(0, 1, " ", "B");

$pdf->Cell(10,7,'',0,1);

$pdf->SetFont('Times','B','10');


$pdf->Cell(20,6,'ID Booking',1,0,'C');
$pdf->Cell(45,6,'Nama Petugas',1,0,'C');
$pdf->Cell(45,6,'Nama Member',1,0,'C');
$pdf->Cell(58,6,'Judul Buku',1,0,'C');
$pdf->Cell(30,6,'Tanggal Booking',1,1,'C');


$pdf->SetFont('Times','',10);

$no=1;
$jk='';
$sid = $_SESSION['idmember'];
//Query untuk mengambil data mahasiswa pada tabel mahasiswa
// $hasil = mysqli_query($kon, "SELECT * FROM buku JOIN kategori ON buku.idkategori = kategori.idkategori JOIN detail_buku ON buku.idbuku = buku.idbuku");
$hasil = mysqli_query($kon, "SELECT * FROM peminjaman INNER JOIN buku ON buku.idbuku = peminjaman.idbuku INNER JOIN petugas ON petugas.idpetugas = peminjaman.idpetugas INNER JOIN member ON member.idmember= peminjaman.idmember WHERE peminjaman.idmember = '".$sid."'");
$data = mysqli_fetch_array($hasil);
    $pdf->Cell(20,6,$data['idpeminjaman'],1,0,'C');
    $pdf->Cell(45,6,$data['nama_petugas'],1,0,'C');
    $pdf->Cell(45,6,$data['nama_member'],1,0,'C');
    $pdf->Cell(58,6,$data['judul'],1,0,'C');
    $pdf->Cell(30,6,$data['tgl_pinjam'],1,1,'C');
    $no++;


$pdf->Output("Struk Booking.pdf", 'I');

?>