<?php

$kon = mysqli_connect("localhost", "root", "", "pra_lsp");

require('../vendor/fpdf/fpdf.php');
$pdf = new FPDF('L', 'mm','Letter');

$pdf->AddPage();

$pdf->SetFont('Arial','B',20);
$pdf->Cell(0,7,'Laporan Data Buku',0,1,'C');

$pdf->SetFont('Arial','B',16);
$pdf->MultiCell(0,12,'Daftar Buku','C');

$pdf->SetFont('Arial','B',12);
$pdf->MultiCell(0,12,"Tanggal : ".date("d-m-Y"),'C');
$pdf->Cell(0, 1, " ", "B");

$pdf->Cell(10,7,'',0,1);

$pdf->SetFont('Arial','B','10');


$pdf->Cell(5,6,'ID',1,0,'C');
$pdf->Cell(18,6,'Kategori',1,0,'C');
$pdf->Cell(75,6,'Judul',1,0,'C');
$pdf->Cell(30,6,'Pengarang',1,0,'C');
$pdf->Cell(25,6,'Penerbit',1,0,'C');
$pdf->Cell(15,6,'Status',1,0,'C');
$pdf->Cell(69,6,'Deskripsi',1,1,'C');


$pdf->SetFont('Times','',10);

$no=1;
$jk='';
//Query untuk mengambil data mahasiswa pada tabel mahasiswa
// $hasil = mysqli_query($kon, "SELECT * FROM buku JOIN kategori ON buku.idkategori = kategori.idkategori JOIN detail_buku ON buku.idbuku = buku.idbuku");
$hasil = mysqli_query($kon, "SELECT * FROM detail_buku JOIN buku ON buku.idbuku = detail_buku.idbuku JOIN kategori ON buku.idkategori = kategori.idkategori");
while ($data = mysqli_fetch_array($hasil)){
    $pdf->Cell(5,6,$data['idbuku'],1,0);
    $pdf->Cell(18,6,$data['kategori'],1,0);
    $pdf->Cell(75,6,$data['judul'],1,0);
    $pdf->Cell(30,6,$data['pengarang'],1,0);
    $pdf->Cell(25,6,$data['penerbit'],1,0);
    $pdf->Cell(15,6,$data['status'],1,0);
    $pdf->Cell(69,6,$data['deskripsi'],1,1);
    $no++;
}

$pdf->Output("Data Buku.pdf", 'I');

?>

