<?php
//menyertakan file fpdf, file fpdf.php di dalam folder FPDF yang diekstrak
require('../vendor/fpdf/fpdf.php');
//membuat objek baru bernama pdf dari class FPDF
//dan melakukan setting kertas l : landscape, A5 : ukuran kertas
$pdf = new FPDF('p','mm','A4');
// membuat halaman baru
$pdf->AddPage();
// menyetel font yang digunakan, font yang digunakan adalah arial, bold dengan ukuran 16
$pdf->SetFont('Arial','B',16);
// judul
$pdf->Cell(190,7,'Laporan Peminjaman',0,1,'C');
$pdf->SetFont('Arial','B',12);
$pdf->Cell(190,7,'Daftar Peminjaman Buku',0,1,'C');
 
// Memberikan space kebawah agar tidak terlalu rapat
$pdf->Cell(10,7,'',0,1);
 
$pdf->SetFont('Arial','B',10);
$pdf->Cell(6,6,'ID',1,0);
$pdf->Cell(40,6,'NAMA PETUGAS',1,0);
$pdf->Cell(45,6,'NAMA MEMBER',1,0);
$pdf->Cell(48,6,'JUDUL BUKU',1,0);
$pdf->Cell(35,6,'TANGGAL PINJAM',1,1);
 
$pdf->SetFont('Arial','',10);
 
//koneksi ke database
$mysqli = new mysqli("localhost","root","","pra_lsp");
$no = 1;
$tampil = mysqli_query($mysqli, "SELECT * FROM peminjaman INNER JOIN admin ON admin.idpetugas = peminjaman.idpetugas INNER JOIN buku ON buku.idbuku = peminjaman.idbuku INNER JOIN member ON member.idmember= peminjaman.idmember");
while 
    ($hasil = mysqli_fetch_array($tampil)){
    $pdf->Cell(6,6,$no++,1,0);
    $pdf->Cell(40,6,$hasil['nama_petugas'],1,0);
     $pdf->Cell(45,6,$hasil['nama_member'],1,0);
    $pdf->Cell(48,6,$hasil['judul'],1,0);
    $pdf->Cell(35,6,$hasil['tgl_pinjam'],1,1); 
}
 
$pdf->Output();


?>