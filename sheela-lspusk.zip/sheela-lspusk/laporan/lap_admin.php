<?php
session_start();

$conn = mysqli_connect("localhost", "root", "", "pra_lsp");

require'../functions.php';
require'../vendor/fpdf/fpdf.php';


$pdf = new FPDF();
$pdf->AddPage('P', 'A4');

$tgl=date('Y/m/d');
// $pdf->Image('../images/latar-kartu.png',5,5,100,56);
// $pdf->Image('../images/latar-kartu.png',106,5,100,56);
// $pdf->Image('../images/logo-perpustakaan.png',10,9,10,10);
// $pdf->Image('../images/foto-default.jpg',80,29,20,25);
$pdf->SetFont('Arial','B',20);
$pdf->Cell(0,7,'DATA KARTU MEMBER',0,1,'C');

$pdf->SetFont('Arial','B',16);
$pdf->MultiCell(0,12,'KARTU MEMBER','C');

$pdf->SetFont('Arial','B',12);
$pdf->MultiCell(0,12,"Tanggal : ".date("d-m-Y"),'C');
$pdf->Cell(0, 1, " ", "B");

$pdf->Cell(10,7,'',0,1);

$pdf->SetFont('Arial','B','10');
$pdf->Ln(3);

// $pdf->Cell(20,6,'ID Petugas', 1,0,'C');
// $pdf->Cell(20,6,': '.$name['idpetugas'],1,0);
// $pdf->Cell(35,6,'Nama Petugas', 1,0,'C');
// $pdf->Cell(35,6,': '. $name['nama_petugas'],1,0);
// $pdf->Cell(30,6,'Username',1,0,'C');
// $pdf->Cell(30,6,': '.$name['username'],1,1);

// $pdf->Cell(40,6,'Tanggal Kembali',1,1,'C');


$member = mysqli_query($conn, "SELECT * FROM member WHERE idmember  ='$_SESSION[idmember]'");
$name = mysqli_fetch_array($member);

$pdf->setFont('Arial','B',10);

$pdf->Cell(20,4,'ID Member',0,0,'C');
$pdf->Cell(15,4,':'.$name['idmember'],0,0);
$pdf->Cell(10,4,'',0,1,'C');
$pdf->Cell(20,4,'   Nama Member',0,0,'C');
$pdf->Cell(15,4,'   :'.$name['nama_member'],0,1);
$pdf->Cell(20,4,'Tempat Lahir',0,0,'C');
$pdf->Cell(10,4,':'.$name['tempat_lahir'],0,1);
$pdf->Cell(20,4,'Tanggal Lahir',0,0,'C');
$pdf->Cell(10,4,':'.$name['tgl_lahir'],0,1);
$pdf->Cell(20,4,'Alamat',0,0,'C');
$pdf->Cell(10,4,':'.$name['alamat'],0,1);
// $pdf->Cell(14,5,'ID Petugas',1,0,'C');
// $pdf->Cell(20,6,': '.$name['idpetugas'],1,0);
// // $pdf->Cell(14,5,'Nama Petugas',1,0,'C');
// $pdf->Cell(35,6,': '. $name['nama_petugas'],1,0);
// // $pdf->Cell(14,5,'username',1,1,'C');
// $pdf->Cell(30,6,': '.$name['username'],1,1);


$pdf->Output('cetak-kartu-identitas-admin.pdf','I');
?>  