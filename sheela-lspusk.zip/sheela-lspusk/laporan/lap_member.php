<?php

$kon = mysqli_connect("localhost", "root", "", "pra_lsp");

require('../vendor/fpdf/fpdf.php');
$pdf = new FPDF('P', 'mm','Letter');

$pdf->AddPage();

$pdf->SetFont('Arial','B',20);
$pdf->Cell(0,7,'Laporan Data Member',0,1,'C');

$pdf->SetFont('Arial','B',16);
$pdf->MultiCell(0,12,'Daftar Member','C');

$pdf->SetFont('Arial','B',12);
$pdf->MultiCell(0,12,"Tanggal : ".date("d-m-Y"),'C');
$pdf->Cell(0, 1, " ", "B");

$pdf->Cell(10,7,'',0,1);

$pdf->SetFont('Arial','B','10');


$pdf->Cell(8,6,'ID',1,0,'C');
$pdf->Cell(40,6,'Nama Member',1,0,'C');
$pdf->Cell(30,6,'Tempat Lahir',1,0,'C');
$pdf->Cell(30,6,'Tanggal Lahir',1,0,'C');
$pdf->Cell(62,6,'Alamat',1,1,'C');


$pdf->SetFont('Times','',10);

$no=1;
$jk='';
//Query untuk mengambil data mahasiswa pada tabel mahasiswa
// $hasil = mysqli_query($kon, "SELECT * FROM buku JOIN kategori ON buku.idkategori = kategori.idkategori JOIN detail_buku ON buku.idbuku = buku.idbuku");
$hasil = mysqli_query($kon, "SELECT * FROM member");
while ($data = mysqli_fetch_array($hasil)){
    $pdf->Cell(8,6,$data['idmember'],1,0);
    $pdf->Cell(40,6,$data['nama_member'],1,0);
    $pdf->Cell(30,6,$data['tempat_lahir'],1,0);
    $pdf->Cell(30,6,$data['tgl_lahir'],1,0);
    $pdf->Cell(62,6,$data['alamat'],1,1);
    $no++;
}

$pdf->Output("Data Buku.pdf", 'I');

?>

