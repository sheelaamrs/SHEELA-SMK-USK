<?php
include'../functions.php';
require'../vendor/fpdf/fpdf.php';
$pdf = new FPDF();
$pdf->AddPage('P','A4');

$tgl=date('Y/m/d');
// $pdf->Image('../images/latar-kartu.png',5,5,100,56);
// $pdf->Image('../images/latar-kartu.png',106,5,100,56);
// $pdf->Image('../images/logo-perpustakaan.png',10,9,10,10);
// $pdf->Image('../images/foto-default.jpg',80,29,20,25);
$pdf->SetFont('Arial','B',20);
$pdf->Cell(0,7,'DATA KARTU MEMBER',0,1,'C');

$pdf->SetFont('Arial','B',16);
$pdf->MultiCell(0,12,'KARTU MEMBER','C');

$pdf->SetFont('Arial','B',12);
$pdf->MultiCell(0,12,"Tanggal : ".date("d-m-Y"),'C');
$pdf->Cell(0, 1, " ", "B");

$pdf->Cell(10,7,'',0,1);

$pdf->SetFont('Arial','B','10');
$pdf->Ln(3);
$pdf->Line(10,25,100,25);
$pdf->Ln(6);

// $idmember=$_GET['idmember'];
$ = mysqli_query($conn, "SELECT * FROM petugas WHERE idpetugas  ='$_SESSION[idpetugas]'");
$name = mysqli_fetch_array($member);
$pdf->setFont('Arial','',10);
$pdf->Cell(14,5,'ID Member',0,0,'L');
$pdf->Cell(76,5,': '.$name['idmember'],0,0,'L');
$pdf->Cell(10,5,'',0,1,'C');
$pdf->setFont('Arial','',10);
$pdf->Cell(14,5,'   Nama Member',0,0,'L');
$pdf->Cell(36,5,': '.$name['nama_member'],0,1,'L');
$pdf->Cell(14,5,'Tempat Lahir',0,0,'L');
$pdf->Cell(36,5,': '.$name['tempat_lahir'],0,1,'L');
$pdf->Cell(14,5,'Tanggal Lahir',0,0,'L');
$pdf->Cell(36,5,': '.$name['tgl_lahir'],0,1,'L');
$pdf->Cell(14,5,'Alamat',0,0,'L');
$pdf->Cell(36,5,': '.$name['alamat'],0,1,'L');
$pdf->Ln(2);

$pdf->Output('cetak-kartu-identitas-anggota.pdf','I');
?>	