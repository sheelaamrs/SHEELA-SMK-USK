<?php 
$conn = mysqli_connect("localhost", "root", "", "pra_lsp");

$iddetailbuku = $_GET['iddetailbuku'];

mysqli_query($conn, "DELETE FROM detail_buku WHERE iddetailbuku = '$iddetailbuku'");

header('location:../detail_buku.php');

 ?>