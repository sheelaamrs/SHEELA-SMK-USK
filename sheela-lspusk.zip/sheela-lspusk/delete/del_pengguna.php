<?php 
$conn = mysqli_connect("localhost", "root", "", "pra_lsp");

$idmember = $_GET['idmember'];

mysqli_query($conn, "DELETE FROM member WHERE idmember = '$idmember'");
mysqli_query($conn, "ALTER TABLE member AUTO_INCREMENT = 0;");

header("location:../d_pengguna.php");

?>