<?php 

$conn = mysqli_connect("localhost", "root", "", "pra_lsp");

$idkategori = $_GET['idkategori'];

mysqli_query($conn, "DELETE FROM kategori WHERE idkategori = '$idkategori'");

header("location:../d_kategori.php");

 ?>



