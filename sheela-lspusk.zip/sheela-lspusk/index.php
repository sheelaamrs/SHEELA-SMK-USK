<?php
session_start();

if (isset($_SESSION["login"])) {
    header("location: index.php");
    exit;
}

require 'functions.php';

if (isset($_POST["login"])) {
    $username = $_POST['username'];
    $password = $_POST['password'];

    $result = mysqli_query($koneksi, "SELECT * FROM petugas WHERE username = '$username'");

    if (!$result) {
        // Jika terjadi kesalahan query, tampilkan pesan kesalahan
        echo "Query Error: " . mysqli_error($koneksi);
        exit;
    }

    // cek username
    if (mysqli_num_rows($result) === 1) {
        // cek password
        $row = mysqli_fetch_assoc($result);
        $_SESSION['idpetugas'] = $row['idpetugas'];

        // Cek apakah password di-hash atau tidak
        if (password_verify($password, $row["password"]) || $password === $row["password"]) {
            // set session 
            $_SESSION["login"] = true;

            header("location: index.php");
            exit;
        }
    }

    $error = true;
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Main CSS-->
    <link rel="stylesheet" type="text/css" href="css/main.css">
    <!-- Font-icon css-->
    <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <title>Login - PUSTULUSA ADMIN</title>
</head>
<body>
    <section class="material-half-bg">
        <div class="cover"></div>
    </section>
    <section class="login-content">
        <div class="logo">
            <h1>PUSTULUSA</h1>
        </div>
        <div class="login-box">
            <form method="POST" class="login-form" action="">
                <h3 class="login-head"><i class="fa fa-lg fa-fw fa-user"></i>LOGIN</h3>
                <div class="form-group">
                    <label class="control-label">USERNAME</label>
                    <input type="text" name="username" placeholder="Masukan Username" required>
                </div>
                <div class="form-group">
                    <label class="control-label">PASSWORD</label>
                    <input type="password" name="password" placeholder="Masukan Password" required>
                </div>
                <div class="form-group">
                    <div class="utility">
                        <div class="animated-checkbox">
                            <label>
                                <input type="checkbox"><span class="label-text">Stay Signed in</span>
                            </label>
                        </div>
                    </div>
                </div>
                <button type="submit" name="login" class="btn btn-primary btn-block">LOGIN</button>
            </form>
            <?php if (isset($error)): ?>
                <div class="alert alert-danger" role="alert">
                    Username atau password salah!
                </div>
            <?php endif; ?>
        </div>
    </section>
</body>
</html>