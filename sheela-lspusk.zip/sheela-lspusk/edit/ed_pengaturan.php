<?php 
session_start();

$conn = mysqli_connect("localhost", "root", "", "pra_lsp");

if (!isset($_SESSION["login"])) {
	header("location: login.php");
	exit;
}

require '../functions.php';

$idpetugas = $_GET['idpetugas'];

if (isset($_POST["ubah"])) {
	if (ubah_petugas($_POST) > 0) {
		echo "<script>
		alert ('Data Disimpan');
		document.location.href = '../pengaturan.php';
		</script>";
	}
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
	<meta name="description" content="" />
	<meta name="author" content="" />
	<title>Halaman Utama &middot; Gudang Buku &middot;</title>
	<link href="../dist/css/styles.css" rel="stylesheet" />
	<link href="https://cdn.datatables.net/1.10.20/css/dataTables.bootstrap4.min.css" rel="stylesheet" crossorigin="anonymous" />
	<script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/js/all.min.js" crossorigin="anonymous"></script>
</head>
<body class="sb-nav-fixed">
	<nav class="sb-topnav navbar navbar-expand navbar-dark bg-dark">
		<a class="navbar-brand" href="index.html">Gudang Buku</a>
		<button class="btn btn-link btn-sm order-1 order-lg-0" id="sidebarToggle" href="#"><i class="fas fa-bars"></i></button>
		<!-- Navbar Search-->
		<form class="d-none d-md-inline-block form-inline ml-auto mr-0 mr-md-3 my-2 my-md-0">
			<div class="input-group">
				<input class="form-control" type="text" placeholder="Search for..." aria-label="Search" aria-describedby="basic-addon2" />
				<div class="input-group-append">
					<button class="btn btn-primary" type="button"><i class="fas fa-search"></i></button>
				</div>
			</div>
		</form>
		<!-- Navbar-->
		<ul class="navbar-nav ml-auto ml-md-0">
			<li class="nav-item dropdown">
				<a class="nav-link dropdown-toggle" id="userDropdown" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="fas fa-user fa-fw"></i></a>
				<div class="dropdown-menu dropdown-menu-right" aria-labelledby="userDropdown">
					<a class="dropdown-item" href="#">Settings</a>
					<a class="dropdown-item" href="#">Activity Log</a>
					<div class="dropdown-divider"></div>
					<a class="dropdown-item" href="logout.php">Logout</a>
				</div>
			</li>
		</ul>
	</nav>
	<div id="layoutSidenav">
		<div id="layoutSidenav_nav">
			<nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
				<div class="sb-sidenav-menu">
					<div class="nav">
						<div class="sb-sidenav-menu-heading"></div>
						<a class="nav-link" style="color: white;" href="pengaturan.php">
							<div class="sb-nav-link-icon" style="color: white;"><i class="fas fa-user-cog"></i></div>
							Pengaturan
						</a>
						<div class="sb-sidenav-menu-heading"></div>
						<a class="nav-link" href="../index.php">
							<div class="sb-nav-link-icon"><i class="fas fa-columns"></i></div>
							Dashbord
						</a>
						<!-- <div class="sb-sidenav-menu-heading"></div> -->
						<a class="nav-link" href="../d_pengguna.php">	
							<div class="sb-nav-link-icon"><i class="fas fa-user"></i></div>
							Member
						</a>

						<!-- <div class="sb-sidenav-menu-heading"></div> -->
						<a class="nav-link" href="../d_buku.php">
							<div class="sb-nav-link-icon"><i class="fas fa-book"></i></div>
							Buku
						</a>

						<!-- <div class="sb-sidenav-menu-heading"></div> -->
						<a class="nav-link" href="../d_kategori.php">
							<div class="sb-nav-link-icon"><i class="fas fa-th-list"></i></div>
							Kategori
						</a>
						<!-- <div class="sb-sidenav-menu-heading"></div> -->
						<a class="nav-link" href="../d_peminjam.php">
							<div class="sb-nav-link-icon"><i class="fas fa-clipboard-list"></i></div>
							Peminjaman
						</a>
						<!-- <div class="sb-sidenav-menu-heading"></div> -->
						<a class="nav-link" href="../d_pengembalian.php">
							<div class="sb-nav-link-icon"><i class="fas fa-handshake"></i></div>
							Pengembalian
						</a>
					</div>
				</div>
				<div class="sb-sidenav-footer">
					<div class="small"><hr></div>
					Gudang Buku
				</div>
			</nav>
		</div>
		<div id="layoutSidenav_content">
			<main>
				<div class="container-fluid">
					<h1 class="mt-4">Pengaturan Akun</h1>
					<ol class="breadcrumb mb-4">
						<li class="breadcrumb-item active">Pengaturan Akun</li>
					</ol>
					<div class="row">

						
					</div>

					<div class="card mb-4 shadow">
						<div class="card-header">
							<i class="fas fa-table mr-1"></i>
							Table Ubah Data
						</div>
						<div class="card-body">
							<div class="table-responsive">
								<form action="" method="POST"><!-- PAKE METHOD POST DAN FORM HARUS ADA DIATAS TABLE -->
									<input type="hidden" name="idpetugas" value=<?php echo $_GET['idpetugas'];?>><!-- HARUS ADA DI BAWAH FORM & ISI VALUE NYA PAKE GET -->
									<table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
										<thead align="center">
											<tr>
												<th>ID</th>
												<th>Nama Admin</th>
												<th>Username</th>
											</tr>
										</thead>
										<tfoot align="center">
											<tr>
												<th>ID</th>
												<th>Nama Admin</th>
												<th>Username</th>
											</tr>
										</tfoot>
										<tbody align="center">
											<?php 
											$petugas = mysqli_query($conn, "SELECT * FROM petugas WHERE idpetugas  ='$idpetugas'");
											$name = mysqli_fetch_array($petugas);
											?>

											<tr bgcolor="white">
												<td><?= $name["idpetugas"]; ?></td>  
												<td><input class="form-control" type="text" name="nama_petugas" value="<?= $name["nama_petugas"]; ?>"></td>
												<td><input class="form-control" type="text" name="username" value="<?= $name["username"];?>"></td>
											</tr>
										</tbody>
									</table>
									<button type="submit" name="ubah" class="btn btn-success btn-sm">Perbarui</button><!-- DIBAWAH TABLE, TAPI DIATAS PENUTUP FORM (</FORM) -->
									&emsp;
									<a href="../pengaturan.php"><span class="btn btn-danger btn-sm">Kembali</span></a>
								</form>
							</div>
						</div>
					</div>
				</div>
			</main>
			<footer class="py-4 bg-light mt-auto">
				<div class="container-fluid">
					<div class="d-flex align-items-center justify-content-between small">
						<div class="text-muted">Copyright &copy; Your Website 2020</div>
						<div>
							<a href="#">Privacy Policy</a>
							&middot;
							<a href="#">Terms &amp; Conditions</a>
						</div>
					</div>
				</div>
			</footer>
		</div>
	</div>
	<style type="text/css">
		@media (min-width: 768px){}
		.col-md-8 {
			flex: 0 0 66.6666666667%;
			max-width: 101.666667%;
		}
	</style>

	<div class="modal fade" id="form_modal" tabindex="-1" role="dialog" aria-hidden="true">
		<div class="modal-dialog" role="document">
			<form action="" method="POST" enctype="multipart/form-data">
				<div class="modal-content">
					<div class="modal-body">

						<div class="col-md-8">
							<div class="form-group">
								<label>Nama Member</label>
								<input class="form-control" type="text" name="nama">
							</div>
							<div class="form-group">
								<label>Tempat Lahir</label>
								<input class="form-control" type="text" name="tptlahir">
							</div>
							<div class="form-group">
								<label>Tanggal Lahir</label>
								<input class="form-control" type="date" name="tgllahir">
							</div>
							<div class="form-group">
								<label>Alamat</label>
								<textarea name="alamat" rows="6" class="form-control" id="message"  required=""></textarea>
							</div>
						</div>
					</div>
					<div style="clear:both;"></div>
					<div class="modal-footer">
						<button type="button" class="btn btn-danger" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span> Close</button>
						<button name="simpan" class="btn btn-primary"><span class="glyphicon glyphicon-save"></span> Save</button>
					</div>
				</div>
			</form>
		</div>
	</div>
	<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" crossorigin="anonymous"></script>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/../dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
	<script src="../dist/js/scripts.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js" crossorigin="anonymous"></script>
	<script src="../dist/assets/demo/chart-area-demo.js"></script>
	<script src="../dist/assets/demo/chart-bar-demo.js"></script>
	<script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js" crossorigin="anonymous"></script>
	<script src="https://cdn.datatables.net/1.10.20/js/dataTables.bootstrap4.min.js" crossorigin="anonymous"></script>
	<script src="../dist/assets/demo/datatables-demo.js"></script>
</body>
</html>
