<?php

$koneksi = mysqli_connect('localhost', 'root', '', 'pra_lsp');

function registrasi($data){
	global $koneksi;

	$nama = ($data['nama']);
	$username = strtolower(stripcslashes($data['username']));
	$password = mysqli_real_escape_string($koneksi, $data['password']);

	// cek username yang sudah ada
	$result = mysqli_query($koneksi, "SELECT username FROM petugas WHERE username = '$username'");

	if (mysqli_fetch_assoc($result)) {
		echo "<script>
		alert ('username sudah terpakai');
		</script> ";
		return false;
	}

	// enkripsi password
	$password = password_hash($password, PASSWORD_DEFAULT);
	
	mysqli_query($koneksi, "INSERT INTO petugas (nama_petugas, username, password) VALUES ('$nama', '$username', '$password')");

	return mysqli_affected_rows($koneksi);
}

function df_admin($data){
	global $koneksi;

	$nama = ($data['nama']);
	$username = strtolower(stripcslashes($data['username']));
	$password = mysqli_real_escape_string($koneksi, $data['password']);

	// cek username yang sudah ada
	$result = mysqli_query($koneksi, "SELECT username FROM admin WHERE username = '$username'");

	if (mysqli_fetch_assoc($result)) {
		echo "<script>
		alert ('username sudah terpakai');
		</script> ";
		return false;
	}

	// enkripsi password
	$password = password_hash($password, PASSWORD_DEFAULT);
	
	mysqli_query($koneksi, "INSERT INTO admin (nama_petugas, username, password) VALUES ('$nama', '$username', '$password')");

	return mysqli_affected_rows($koneksi);
}

function daftar($data){
	global $koneksi;

	$nama = ($data['nama']);
	$idmember = strtolower(stripcslashes($data['idmember']));
	$password = mysqli_real_escape_string($koneksi, $data['password']);

	// cek username yang sudah ada
	$result = mysqli_query($koneksi, "SELECT idmember FROM member WHERE idmember = '$idmember'");

	if (mysqli_fetch_assoc($result)) {
		echo "<script>
		alert ('id member sudah terpakai');
		</script> ";
		return false;
	}

	// enkripsi password
	$password = password_hash($password, PASSWORD_DEFAULT);
	
	mysqli_query($koneksi, "INSERT INTO member (nama_member, idmember, password) VALUES ('$nama', '$idmember', '$password')");

	return mysqli_affected_rows($koneksi);
}


function simpan_buku($data){
	global $koneksi;

	$kategori = ($data['kategori']);
	$judul = ($data['judul']);
	$pengarang = ($data['pengarang']);
	$penerbit = ($data['penerbit']);
	$deskripsi = ($data['deskripsi']);

	mysqli_query($koneksi, "INSERT INTO buku (idkategori, judul, pengarang, penerbit, deskripsi) values ('$kategori', '$judul', '$pengarang', '$penerbit', '$deskripsi')");

	//BUAT MANGGIL ID BERDASARKAN ID TERAKHIR DI SQL
	$idbuku = mysqli_insert_id($koneksi);
	//VARIABLE MANUAL
	$status = "Ada";

	mysqli_query($koneksi, "INSERT INTO detail_buku (idbuku, status) VALUES ('$idbuku', '$status')");

	return mysqli_affected_rows($koneksi);
}


function simpan_kategori($data){
	global $koneksi;

	$kategori = ($data['kategori']);

	mysqli_query($koneksi, "INSERT INTO kategori (kategori) values ('$kategori')");

	return mysqli_affected_rows($koneksi);
}


function simpan_status($data){
	global $koneksi;

	$detail_buku = ($data['detail_buku']);
	$status = ($data['status']);

	mysqli_query($koneksi, "INSERT INTO detail_buku (idbuku, status) values ('$detail_buku', '$status')");

	return mysqli_affected_rows($koneksi);
}


function simpan_member($data) {
	global $koneksi;

	$nama = ($data['nama']);
	$tptlahir = ($data['tptlahir']);
	$tgllahir = ($data['tgllahir']);
	$alamat = ($data['alamat']);

	mysqli_query($koneksi, "INSERT INTO member (nama_member, tempat_lahir, tgl_lahir, alamat) VALUES ('$nama', '$tptlahir', '$tgllahir', '$alamat') ");

	return mysqli_affected_rows($koneksi);
}

function simpan_peminjam($data){
	global $koneksi;

	$idpetugas = ($data["idpetugas"]);
	$idmember = ($data['idmember']);
	$idbuku = ($data['idbuku']);

	$Dipinjam = "Dipinjam";

	mysqli_query($koneksi, "INSERT INTO peminjaman (idpetugas, idmember, idbuku, tgl_pinjam) values ('$idpetugas', '$idmember', '$idbuku', '" . date('Y-m-d') . "')");
	mysqli_query($koneksi, "UPDATE detail_buku SET status = '$Dipinjam' WHERE idbuku = $idbuku ");

	return mysqli_affected_rows($koneksi);
	}
function pinjam_simpan($data){
	global $koneksi;

	$idpetugas = ($data["idpetugas"]);
	$idmember = ($data['idmember']);
	$idbuku = ($data['idbuku']);
	// $tgl_pinjam = ($data['tgl_pinjam']);

	$Dipinjam = "Dipinjam";

	mysqli_query($koneksi, "INSERT INTO peminjaman (idpetugas, idmember, idbuku, tgl_pinjam) values ('$idpetugas', '$idmember', '$idbuku', '" . date('Y-m-d') . "')");
	mysqli_query($koneksi, "UPDATE detail_buku SET status = '$Dipinjam' WHERE idbuku = $idbuku ");

	return mysqli_affected_rows($koneksi);
	}

function save_petugas($data){
	global $koneksi;

	$nama_petugas = ($data["nama_petugas"]);
	$username = ($data["username"]);
	$password = ($data["password"]);

	mysqli_query($koneksi, "INSERT INTO admin ( nama_petugas, username, password) values ( '$nama_petugas', '$username', '$password')");

	return mysqli_affected_rows($koneksi);
}
	function simpan_pengembalian($data){
		global $koneksi;

		$idpeminjaman = ($data['idpeminjaman']);
		$iddetailbuku = ($data['iddetailbuku']);

		$ada = "Ada";
		$ada = "kembali";
	// $delete = "DELETE FROM peminjaman WHERE idpeminjaman = $idpeminjaman";
		$update = "UPDATE detail_buku SET status = '$ada' WHERE idbuku = $iddetailbuku";
		$simpan = "UPDATE idpeminjaman SET status = '$kembali' WHERE idbuku = $iddetailbuku";
		$insert = "INSERT INTO detail_peminjaman (idpeminjaman, iddetailbuku, tgl_kembali) values ('$idpeminjaman', '$iddetailbuku', '" . date('Y-m-d') . "')";
			

			$result2 = mysqli_query($koneksi,$insert);
	// $result3 = mysqli_query($koneksi,$delete);
			$result = mysqli_query($koneksi,$update);
			
			
			return mysqli_affected_rows($koneksi);
		}



//=================\\
// FUNGSI UBAH DATA\\
//=================\\
		function ubah_kategori($data){
			global $koneksi;

			$idkategori = $data ["idkategori"];
			$kategori = htmlspecialchars($data["kategori"]);

			mysqli_query($koneksi, "UPDATE kategori SET kategori = '$kategori' WHERE idkategori = $idkategori ");

			return mysqli_affected_rows($koneksi);
		}


		function ubah_member($data){
			global $koneksi;

			$idmember = $data ["idmember"];
			$nama_member = ($data["nama_member"]);
			$tempat_lahir = ($data["tempat_lahir"]);
			$tgl_lahir = ($data["tgl_lahir"]);
			$alamat = ($data["alamat"]);

			mysqli_query($koneksi, "UPDATE member SET nama_member = '$nama_member', tempat_lahir = '$tempat_lahir', tgl_lahir = '$tgl_lahir', alamat = '$alamat' WHERE idmember = $idmember");

			return mysqli_affected_rows($koneksi);
		}


		function ubah_buku($data){
			global $koneksi;
			$idbuku = $data ["idbuku"];
			$idkategori = $data["kategori"];
			$judul = ($data["judul"]);
			$pengarang = ($data["pengarang"]);
			$penerbit = ($data["penerbit"]);
			$deskripsi = ($data["deskripsi"]);
			$status = ($data['status']);

			mysqli_query($koneksi, "UPDATE buku SET idkategori = '$idkategori', judul = '$judul', pengarang = '$pengarang', penerbit = '$penerbit', deskripsi = '$deskripsi' WHERE idbuku = $idbuku");

			mysqli_query($koneksi, "UPDATE detail_buku SET status = '$status' WHERE idbuku = '$idbuku'");

			return mysqli_affected_rows($koneksi);
		}
function ubah_pinjam($data){
			global $koneksi;
			$idpeminjaman = ($data ["idpeminjaman"]);
			$idpetugas = ($data["idpetugas"]);
			$idmember = ($data["idmember"]);
			$idbuku = ($data["idbuku"]);
			$tgl_pinjam = ($data["tgl_pinjam"]);
			// $deskripsi = ($data["deskripsi"]);
			// $status = ($data['status']);

			mysqli_query($koneksi, "UPDATE peminjaman SET idpetugas = '$idpetugas', idbuku = '$idbuku', idmember = '$idmember', tgl_pinjam = '$tgl_pinjam' WHERE idpeminjaman = $idpeminjaman");

			// mysqli_query($koneksi, "UPDATE detail_buku SET status = '$status' WHERE idbuku = '$idbuku'");

			return mysqli_affected_rows($koneksi);
		}


		function ubah_detail($data){
			global $koneksi;

			$iddetailbuku = $data ["iddetailbuku"];
			
			$status = ($data["status"]);

			mysqli_query($koneksi, "UPDATE detail_buku SET status = '$status' WHERE iddetailbuku = $iddetailbuku");

			return mysqli_affected_rows($koneksi);
		}

		function ubah_petugas($data) {
			global $koneksi;

			$idpetugas = ($data["idpetugas"]);
			$nama_petugas = ($data["nama_petugas"]);
			$username = ($data["username"]);

			mysqli_query($koneksi, "UPDATE petugas SET nama_petugas = '$nama_petugas', username = '$username' WHERE idpetugas = '$idpetugas'");

			return mysqli_affected_rows($koneksi);

		}
function ubah_admin ($data) {
			global $koneksi;
			$idpetugas = ($data["idpetugas"]);
			$nama_petugas = ($data["nama_petugas"]);
			$username = ($data["username"]);
			$password = ($data["password"]);

			mysqli_query($koneksi, "UPDATE admin SET nama_petugas = '$nama_petugas', username = '$username', password = '$password' WHERE idpetugas = '$idpetugas'");

			return mysqli_affected_rows($koneksi);

		}		

		function admin_setting ($data) {
			global $koneksi;

			$idpetugas = ($data["idpetugas"]);
			$nama_petugas = ($data["nama_petugas"]);
			$username = ($data["username"]);

			mysqli_query($koneksi, "UPDATE petugas SET nama_petugas = '$nama_petugas', username = '$username' WHERE idpetugas = '$idpetugas'");

			return mysqli_affected_rows($koneksi);

		}
//INI WM
function set_member($data) {
global $koneksi;
			$idmember = ($data["idmember"]);
			$nama_member = ($data["nama_member"]);
			$tempat_lahir = ($data["tempat_lahir"]);
			$tgl_lahir = ($data["tgl_lahir"]);
			$alamat = ($data["alamat"]);

			mysqli_query($koneksi, "UPDATE member SET nama_member = '$nama_member', tempat_lahir = '$tempat_lahir' ,tgl_lahir = '$tgl_lahir', alamat = '$alamat'  WHERE idmember = '$idmember'");

			return mysqli_affected_rows($koneksi);

		}


	?>