-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 12, 2022 at 08:20 AM
-- Server version: 10.4.13-MariaDB
-- PHP Version: 7.4.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pra_lsp`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `idpetugas` int(11) NOT NULL,
  `nama_petugas` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` int(128) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`idpetugas`, `nama_petugas`, `username`, `password`) VALUES
(3, 'Mutiara Sukma', 'sukma123', 0),
(5, 'Pustaka', 'petugas', 0),
(6, 'petugass', 'petugass', 2222),
(7, 'Anita', 'anita', 1313),
(8, 'Ridwan', 'ridwan', 123),
(9, 'Aulia', 'aulia', 0);

-- --------------------------------------------------------

--
-- Table structure for table `buku`
--

CREATE TABLE `buku` (
  `idbuku` int(11) NOT NULL,
  `idkategori` int(11) NOT NULL,
  `judul` varchar(128) NOT NULL,
  `pengarang` varchar(128) NOT NULL,
  `penerbit` varchar(128) NOT NULL,
  `deskripsi` varchar(512) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `buku`
--

INSERT INTO `buku` (`idbuku`, `idkategori`, `judul`, `pengarang`, `penerbit`, `deskripsi`) VALUES
(1, 2, 'Kamus Bahasa Inggris', 'John M. Echols', 'Gramedia', 'Untuk mentranslate'),
(2, 1, 'Buku Simulasi Digital', 'Eko Subiyantoro ', 'Erlangga', 'Buku Paket kelas X'),
(3, 3, 'Kamus Basket', 'Yolis Y.A. Djami', 'Deepublish ', ' sajian kata yang digunakan dalam basket.'),
(4, 1, 'Pemrograman Web', 'Patwiyanto', 'Erlangga', 'Program Keahlian TIK keahlian RPL '),
(5, 1, 'BUKU X-PRESS US SMK MATEMATIKA', 'Kasmina', 'Erlangga', 'Buku Latihan Soal USBN Matematika SMK'),
(6, 6, 'Kata', 'Tsana', 'Erlangga', 'Cerita Fiksi'),
(7, 6, 'Gezz And Ann', 'Tsana', 'Manoj Punjabi', 'Kisah Cinta Remaja Fiksi'),
(8, 8, 'Soekarno Hatta', 'Patwiyanto', 'Erlangga', 'Buku Sejarah');

-- --------------------------------------------------------

--
-- Table structure for table `detail_buku`
--

CREATE TABLE `detail_buku` (
  `iddetailbuku` int(11) NOT NULL,
  `idbuku` int(11) NOT NULL,
  `status` enum('Dipinjam','Ada') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `detail_buku`
--

INSERT INTO `detail_buku` (`iddetailbuku`, `idbuku`, `status`) VALUES
(1, 1, 'Ada'),
(2, 2, 'Ada'),
(3, 3, 'Ada'),
(4, 4, 'Ada'),
(5, 5, 'Ada'),
(6, 6, 'Ada'),
(7, 7, 'Ada'),
(8, 8, '');

--
-- Triggers `detail_buku`
--
DELIMITER $$
CREATE TRIGGER `hapus_buku` AFTER DELETE ON `detail_buku` FOR EACH ROW BEGIN DELETE FROM buku WHERE idbuku = OLD.idbuku; END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `detail_peminjaman`
--

CREATE TABLE `detail_peminjaman` (
  `iddetail_peminjaman` int(11) NOT NULL,
  `idpeminjaman` int(11) NOT NULL,
  `iddetailbuku` int(11) NOT NULL,
  `tgl_kembali` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `detail_peminjaman`
--

INSERT INTO `detail_peminjaman` (`iddetail_peminjaman`, `idpeminjaman`, `iddetailbuku`, `tgl_kembali`) VALUES
(19, 70, 1, '2022-03-11'),
(20, 0, 6, '2022-03-11'),
(21, 119, 4, '2022-03-12'),
(22, 120, 8, '2022-03-12');

--
-- Triggers `detail_peminjaman`
--
DELIMITER $$
CREATE TRIGGER `hapuspeminjam` AFTER INSERT ON `detail_peminjaman` FOR EACH ROW BEGIN DELETE FROM peminjaman WHERE idpeminjaman = NEW.idpeminjaman; END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `kategori`
--

CREATE TABLE `kategori` (
  `idkategori` int(11) NOT NULL,
  `kategori` varchar(128) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `kategori`
--

INSERT INTO `kategori` (`idkategori`, `kategori`) VALUES
(1, 'Pelajaran'),
(2, 'Bahasa'),
(3, 'Olahraga'),
(4, 'Seni'),
(5, 'Kewirausahaan'),
(6, 'Novel'),
(7, 'Film'),
(8, 'Sejarah');

-- --------------------------------------------------------

--
-- Table structure for table `member`
--

CREATE TABLE `member` (
  `idmember` int(11) NOT NULL,
  `nama_member` varchar(50) NOT NULL,
  `tempat_lahir` varchar(50) NOT NULL,
  `tgl_lahir` date NOT NULL,
  `alamat` varchar(128) NOT NULL,
  `password` varchar(128) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `member`
--

INSERT INTO `member` (`idmember`, `nama_member`, `tempat_lahir`, `tgl_lahir`, `alamat`, `password`) VALUES
(1, 'Tawan Vihokratana', 'Bandung', '2002-07-22', 'Jl. Serdang', ''),
(4, 'Aulia Nur Salamah', 'Jakarta', '2003-10-27', 'Duren Sawit', ''),
(5, 'Rajwa Alimah Mahdri', 'Jakarta', '2005-02-25', 'Lampiri', ''),
(6, 'Ismi Khasanah', 'Jakarta', '2004-02-04', 'Cakung', ''),
(7, 'Ryan Wijaya', 'bogor', '2022-03-10', '        Bandung Barat IV', '$2y$10$R.Wcv1ilRpFbTkq9Jf9EPeJ0pXn/P11e9N.TXLO2W/LGVD.UDsuZy'),
(8, 'Sheela Mutiara', 'Jakarta', '2022-03-12', 'Pedati', ''),
(9, 'Indra Kenz', 'Jakarta', '2022-03-12', 'Jaksel', '');

-- --------------------------------------------------------

--
-- Table structure for table `peminjaman`
--

CREATE TABLE `peminjaman` (
  `idpeminjaman` int(11) NOT NULL,
  `idpetugas` int(11) NOT NULL,
  `idmember` int(11) NOT NULL,
  `idbuku` int(11) NOT NULL,
  `tgl_pinjam` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `peminjaman`
--

INSERT INTO `peminjaman` (`idpeminjaman`, `idpetugas`, `idmember`, `idbuku`, `tgl_pinjam`) VALUES
(116, 5, 1, 1, '2022-03-12'),
(117, 16, 5, 4, '2022-03-12'),
(118, 7, 1, 2, '2022-03-12');

-- --------------------------------------------------------

--
-- Table structure for table `petugas`
--

CREATE TABLE `petugas` (
  `idpetugas` int(11) NOT NULL,
  `nama_petugas` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(128) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `petugas`
--

INSERT INTO `petugas` (`idpetugas`, `nama_petugas`, `username`, `password`) VALUES
(16, 'Sheela Mutiara', 'admin', '$2y$10$CwDrFAX3xpr39RNLEqc8O.1TY1bAycYJyXGw7yzk8n8EwT7sMPTFu');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`idpetugas`);

--
-- Indexes for table `buku`
--
ALTER TABLE `buku`
  ADD PRIMARY KEY (`idbuku`),
  ADD KEY `idkategori` (`idkategori`);

--
-- Indexes for table `detail_buku`
--
ALTER TABLE `detail_buku`
  ADD PRIMARY KEY (`iddetailbuku`),
  ADD KEY `idbuku` (`idbuku`);

--
-- Indexes for table `detail_peminjaman`
--
ALTER TABLE `detail_peminjaman`
  ADD PRIMARY KEY (`iddetail_peminjaman`),
  ADD KEY `idpeminjaman` (`idpeminjaman`),
  ADD KEY `iddetailbuku` (`iddetailbuku`);

--
-- Indexes for table `kategori`
--
ALTER TABLE `kategori`
  ADD PRIMARY KEY (`idkategori`);

--
-- Indexes for table `member`
--
ALTER TABLE `member`
  ADD PRIMARY KEY (`idmember`);

--
-- Indexes for table `peminjaman`
--
ALTER TABLE `peminjaman`
  ADD PRIMARY KEY (`idpeminjaman`),
  ADD KEY `idmember` (`idmember`),
  ADD KEY `idpetugas` (`idpetugas`);

--
-- Indexes for table `petugas`
--
ALTER TABLE `petugas`
  ADD PRIMARY KEY (`idpetugas`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `idpetugas` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `buku`
--
ALTER TABLE `buku`
  MODIFY `idbuku` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `detail_buku`
--
ALTER TABLE `detail_buku`
  MODIFY `iddetailbuku` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `detail_peminjaman`
--
ALTER TABLE `detail_peminjaman`
  MODIFY `iddetail_peminjaman` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `kategori`
--
ALTER TABLE `kategori`
  MODIFY `idkategori` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `member`
--
ALTER TABLE `member`
  MODIFY `idmember` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `peminjaman`
--
ALTER TABLE `peminjaman`
  MODIFY `idpeminjaman` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=121;

--
-- AUTO_INCREMENT for table `petugas`
--
ALTER TABLE `petugas`
  MODIFY `idpetugas` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `buku`
--
ALTER TABLE `buku`
  ADD CONSTRAINT `buku_ibfk_1` FOREIGN KEY (`idkategori`) REFERENCES `kategori` (`idkategori`);

--
-- Constraints for table `detail_buku`
--
ALTER TABLE `detail_buku`
  ADD CONSTRAINT `detail_buku_ibfk_1` FOREIGN KEY (`idbuku`) REFERENCES `buku` (`idbuku`);

--
-- Constraints for table `detail_peminjaman`
--
ALTER TABLE `detail_peminjaman`
  ADD CONSTRAINT `detail_peminjaman_ibfk_2` FOREIGN KEY (`iddetailbuku`) REFERENCES `detail_buku` (`iddetailbuku`);

--
-- Constraints for table `peminjaman`
--
ALTER TABLE `peminjaman`
  ADD CONSTRAINT `peminjaman_ibfk_1` FOREIGN KEY (`idpetugas`) REFERENCES `petugas` (`idpetugas`),
  ADD CONSTRAINT `peminjaman_ibfk_2` FOREIGN KEY (`idmember`) REFERENCES `member` (`idmember`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
