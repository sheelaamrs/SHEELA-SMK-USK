<?php 
$conn = mysqli_connect("localhost", "root", "", "pra_lsp");

$idpeminjaman = $_GET['idpeminjaman'];


mysqli_query($conn, "DELETE FROM peminjaman WHERE idpeminjaman = '$idpeminjaman' ");
mysqli_query($conn, "ALTER TABLE idpeminjaman AUTO_INCREMENT = 0;");
mysqli_query($conn, "ALTER TABLE idpetugas AUTO_INCREMENT = 0;");
mysqli_query($conn, "ALTER TABLE idmember AUTO_INCREMENT = 0;");

header("location: data-peminjam.php");

 ?>