<?php
session_start();

if (isset($_SESSION["login"])) {
	header("location: index2.php");
	exit;
}

require 'functions.php';

if (isset($_POST["login"])) {

	$nama_member = $_POST['nama_member'];
	$idmember = $_POST['idmember'];

	 $result = mysqli_query($koneksi, "SELECT * FROM member WHERE nama_member ='$nama_member' AND idmember ='$idmember'");
    if (mysqli_num_rows($result) > 0){
      $_SESSION['nama_member'] = $nama_member;
      $_SESSION['idmember'] = $idmember;
      header("location:index2.php");
    }else{
      echo "<script>
      alert('Username atau Password salah');
      document.location.href = 'loginmem.php';
      </script>";
    }
  }

  $error = true;

?>

<!DOCTYPE html>
<html>
<head>
	 <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Main CSS-->
    <link rel="stylesheet" type="text/css" href="css/main.css">
    <!-- Font-icon css-->
    <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <title>Login - PUSTULUSA ADMIN</title>
</head>
<body>
	<section class="material-half-bg">
      <div class="cover"></div>
    </section>
    <section class="login-content">
      <div class="logo">
        <h1>PUSTULUSA</h1>
      </div>

			<form method="POST">
				<div class="login-box">
        <form class="login-form" action="index.php">
          <h3 class="login-head"><i class="fa fa-lg fa-fw fa-user"></i>LOGIN</h3>
          <div class="form-group">
          		<label class="control-label">ID MEMBER</label>
				<input type="text" name="idmember" placeholder="Masukan ID Member">
				<div class="form-group">
            	<label class="control-label">NAMA</label>
				<input type="text" name="nama_member" placeholder="Masukan Nama">
				<div class="form-group">
            	<div class="utility">
              	<div class="animated-checkbox">
                <label>
                  <input type="checkbox"><span class="label-text">Stay Signed in</span>
                </label>
               <tr><p class="semibold-text mb-2">Belum Punya Akun?<a href="daftarmem.php" > Daftar </a>Sekarang</p>
               </tr>
				<button type="submit" name="login">LOGIN</button>
			</form>
		</div>
	</div>
</body>
</html>