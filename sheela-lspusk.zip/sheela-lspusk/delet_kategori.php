<?php 

$conn = mysqli_connect("localhost", "root", "", "pra_lsp");

$idkategori = $_GET['idkategori'];

mysqli_query($conn, "DELETE FROM kategori WHERE idkategori = '$idkategori'");
mysqli_query($conn, "ALTER TABLE kategori AUTO_INCREMENT = 0;");


header("location:kategori-buku.php");

 ?>



