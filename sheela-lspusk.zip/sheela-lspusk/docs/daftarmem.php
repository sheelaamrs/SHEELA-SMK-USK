<?php
require 'functions.php';

session_start();


if (isset($_SESSION["login"])) {
	header("location: index2.php");
	exit;
}

// register sesuai dengan nama type submitnya dan untuk registrasi sesuai dengan function
if (isset($_POST["register"])) {

	if (daftar($_POST) > 0) {
		echo "<script>
					alert ('akun berhasil dibuat');
					document.location.href = 'loginmem.php';
				</script> ";
	} else {
		echo mysqli_error($koneksi);
	}
}


?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Main CSS-->
    <link rel="stylesheet" type="text/css" href="css/main.css">
    <!-- Font-icon css-->
    <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <title>Register - PUSTULUSA ADMIN</title>
</head>
<body>
	 <section class="material-half-bg">
      <div class="cover"></div>
    </section>
    <section class="login-content">
      <div class="logo">
        <h1>PUSTULUSA</h1>
      </div>
		
			<form method="POST">
		<div class="login-box">
        <form class="login-form" action="login.php">
				<h3 class="login-head"><i class="fa fa-lg fa-fw fa-user"></i>REGISTER ADMIN</h3>
				<div class="form-group">
				<label class="control-label">NAMA</label>
				<input type="text" name="nama" placeholder="Masukan Nama Lengkap">
				<div class="form-group">
				<label class="control-label">ID MEMBER</label>
				<input type="text" name="idmember" placeholder="Masukan Username">
				<div class="form-group">
				<label class="control-label">PASSWORD</label>
				<input type="password" name="password" placeholder="Masukan Password">
				<p class="semibold-text mb-2">Sudah Punya Akun?<a href="loginmem.php"> Login </a>Sekarang</p>
            </div>
				<button type="submit" name="register">Daftar</button>
			</form>
		</div>
	</div>
</body>
</html>