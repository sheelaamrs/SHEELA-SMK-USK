<?php

session_start();

$conn = mysqli_connect("localhost", "root", "", "pra_lsp");

//if (!isset($_SESSION["login"])) {
  //header("location: login.php");
  //exit;
//}
// if ($_SESSION["jabatan"]=="pengguna") {
//   header("location: index.php");
//   exit;
// }
require 'functions.php';

$member = mysqli_query($conn, "SELECT * FROM member WHERE idmember  ='$_SESSION[idmember]'");
// $name = mysqli_fetch_array($member);

// // // mengambil data barang
$total = mysqli_query($conn, "SELECT * FROM peminjaman");

// // // menghitung data barang
$jumlah_pinjaman = mysqli_num_rows($total);


// register sesuai dengan nama type submitnya dan untuk registrasi sesuai dengan function
if (isset($_POST["simpan"])) {

    if (simpan_pinjam($_POST) > 0) {
        echo "<script>
        alert ('Data Disimpan');
        document.location.href = 'pinjam.php';
        </script> ";
    } else {
        echo mysqli_error($koneksi);
    }
}



if (!$conn) {
    die ("Koneksi gagal. " . mysqli_connect_error()); // close koneksi
}
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta name="description" content="Vali is a responsive and free admin theme built with Bootstrap 4, SASS and PUG.js. It's fully customizable and modular.">
    <!-- Twitter meta-->
    <meta property="twitter:card" content="summary_large_image">
    <meta property="twitter:site" content="@pratikborsadiya">
    <meta property="twitter:creator" content="@pratikborsadiya">
    <!-- Open Graph Meta-->
    <meta property="og:type" content="website">
    <meta property="og:site_name" content="Vali Admin">
    <meta property="og:title" content="Vali - Free Bootstrap 4 admin theme">
    <meta property="og:url" content="http://pratikborsadiya.in/blog/vali-admin">
    <meta property="og:image" content="http://pratikborsadiya.in/blog/vali-admin/hero-social.png">
    <meta property="og:description" content="Vali is a responsive and free admin theme built with Bootstrap 4, SASS and PUG.js. It's fully customizable and modular.">
    <title>Data Peminjaman-Pustulusa Admin</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Main CSS-->
    <link rel="stylesheet" type="text/css" href="css/main.css">
    <!-- Font-icon css-->
    <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  </head>
  <body class="app sidebar-mini rtl">
    <!-- Navbar-->
    <header class="app-header"><a class="app-header__logo" href="index.php">PUSTULUSA</a>
      <!-- Sidebar toggle button--><a class="app-sidebar__toggle" href="#" data-toggle="sidebar" aria-label="Hide Sidebar"></a>
      <!-- Navbar Right Menu-->
      <ul class="app-nav">
        <li class="app-search">
          <input class="app-search__input" type="search" placeholder="Search">
          <button class="app-search__button"><i class="fa fa-search"></i></button>
        </li>
         <!-- User Menu-->
       <li class="dropdown"><a class="app-nav__item" href="#" data-toggle="dropdown" aria-label="Open Profile Menu"><i class="fa fa-user fa-lg"></i></a>
          <ul class="dropdown-menu settings-menu dropdown-menu-right">
            <li><a class="dropdown-item" href="set_member.php"><i class="fa fa-user fa-lg"></i> Profile</a></li>
            <li><a class="dropdown-item" href="logout.php"><i class="fa fa-sign-out fa-lg"></i> Logout</a></li>
          </ul>
        </li>
      </ul>
    </header>
    <!-- Sidebar menu-->
    <div class="app-sidebar__overlay" data-toggle="sidebar"></div>
    <aside class="app-sidebar">
      <div class="app-sidebar__user"><img class="app-sidebar__user-avatar" src="img/logoo.png" alt="User Image">
        <div>
             <p class="app-sidebar__user-name">MEMBER</p>
          <p class="text-muted m-0">Dashboard Member</p>
        </div>
      </div>
      <ul class="app-menu">
        <li><a class="app-menu__item" href="index2.php"><i class="app-menu__icon fa fa-dashboard"></i><span class="app-menu__label">Dashboard</span></a></li>
        <li><a class="app-menu__item" href="kat_buku.php"><i class="app-menu__icon fa fa-list-ul"></i><span class="app-menu__label">Kategori Buku</span></a></li>
         <li><a class="app-menu__item" href="dat_buku.php"><i class="app-menu__icon fa fa-book"></i><span class="app-menu__label">Data Buku</span></a></li>
         <li><a class="app-menu__item" href="dat_pinjam.php"><i class="app-menu__icon fa fa-list-ul"></i><span class="app-menu__label">Pinjam</span></a></li>
    </aside>
    <main class="app-content">
      <div class="app-title">
        <div>
          <h1><i class="icon fa fa-tasks"></i> Data Pinjam</h1>
          <p>Table Data Pinjam Website PUSTULUSA</p>
        </div>
        <ul class="app-breadcrumb breadcrumb side">
          <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
          <li class="breadcrumb-item">Pinjam Buku</li>
          <li class="breadcrumb-item active"><a href="#"> Data Pinjam</a></li>
        </ul>
      </div>
      <div class="row">
        <div class="col-md-12">
          <div class="bs-component">
                <h4 class="card-header"><i class="icon fa fa-tasks" aria-hidden="true"></i>  Data Pinjam</h4>
          <div class="tile">
            <div class="tile-body">
              <table class="table table-hover table-bordered" id="sampleTable">
                <thead>
                <tbody align="center">
              <div class="modal fade" id="form_modal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <form action="" method="POST" enctype="multipart/form-data">
            <div class="modal-content">
                <div class="modal-body">
                    <div class="col-md-8">
             <tr bgcolor="white">
             	<div class="form-group">
             <label>Nama Member</label>
                            <?php 
                            $query = mysqli_query($conn, "SELECT * FROM member WHERE idmember" );
                             // WHILE($data2 = $query->fetch_assoc()):
                            //$member = mysqli_query($conn, "SELECT * FROM member WHERE idmember  ='$_SESSION[idmember]'");
                            $name = mysqli_fetch_array($member);

                            ?>
                             <input type="hidden" class="form-control" name="idmember" value="<?= $name['idmember']; ?>">
                            <input type="text" disabled class="form-control" value="<?php echo "[", $name['idmember'], "]   ", $name['nama_member']; ?>">    
                        </div>
                         <div class="form-group">
                        <label>ID Buku</label>
                        <input class="form-control" name="idbuku" list="dattalistOptions" id="exampleDataList" required placeholder="-----PILIH BUKU-----">
                        <datalist id="dattalistOptions">
                            <?php 
                            $queryy = mysqli_query($conn, "SELECT * FROM detail_buku JOIN buku ON detail_buku.idbuku = buku.idbuku WHERE status = 'Ada' ");

                            WHILE($data3 = $queryy->fetch_assoc()):

                            ?>
                            <option value="<?= $data3['idbuku']; ?>"><?php echo $data3['judul'];?></option>
                        <?php endwhile; ?> 
                    </datalist>
                </div>

                <div class="form-group">
                    <label>Tanggal Pinjam</label>
                    <input type="aria-hidden" disabled class="form-control" value="<?php echo date("d-m-Y"); ?>">

                </div>
                <div style="clear:both;"></div>
                <div class="modal-footer">
                  <button name="simpan" class="btn btn-primary"><span class="glyphicon glyphicon-save"></span> Save</button> &nbsp; <a href="pinjam.php" ><button type="button" class="btn btn-danger"><span class="glyphicon glyphicon-plus"></span>Lihat Data</button></a> </p></p>
                    </tr>
                                </form>
                            </tbody>
                        </table>
              </table>
            </div>
                </div>
            </div>
        </form>
    </div>
</div>

          </div>
        </div>
      </div>
    </main>
    <!-- Essential javascripts for application to work-->
    <script src="js/jquery-3.2.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/main.js"></script>
    <!-- The javascript plugin to display page loading on top-->
    <script src="js/plugins/pace.min.js"></script>
    <!-- Page specific javascripts-->
    <!-- Data table plugin-->
    <script type="text/javascript" src="js/plugins/jquery.dataTables.min.js"></script>
    <script type="text/javascript" src="js/plugins/dataTables.bootstrap.min.js"></script>
    <script type="text/javascript">$('#sampleTable').DataTable();</script>
    <!-- Google analytics script-->
    <script type="text/javascript">
      if(document.location.hostname == 'pratikborsadiya.in') {
      	(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
      	(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
      	m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
      	})(window,document,'script','//www.google-analytics.com/analytics.js','ga');
      	ga('create', 'UA-72504830-1', 'auto');
      	ga('send', 'pageview');
      }
    </script>
  </body>
</html>
