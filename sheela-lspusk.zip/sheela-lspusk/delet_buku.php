<?php 
$conn = mysqli_connect("localhost", "root", "", "pra_lsp");

$idbuku = $_GET['idbuku'];


mysqli_query($conn, "DELETE FROM detail_buku WHERE idbuku = '$idbuku' ");
mysqli_query($conn, "ALTER TABLE detail_buku AUTO_INCREMENT = 0;");
mysqli_query($conn, "ALTER TABLE buku AUTO_INCREMENT = 0;");

header("location: data-buku.php");

 ?>