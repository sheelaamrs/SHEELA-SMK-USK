<?php

session_start();

$conn = mysqli_connect("localhost", "root", "", "pra_lsp");

?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
   <!--MY CSS -->
   <link rel="stylesheet" type="text/css" href="css/landing.css">
   <!-- FONTS -->
   <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Amaranth:wght@700&display=swap" rel="stylesheet">
    <title>PUSTAKA TUJUH PULUH SATU</title>
  </head>
  <body style="background-color : whitesmoke;">
   <!-- NAVBAR -->
   <div id="header">
    <!-- <div class="container"> -->
   <nav class="navbar navbar-expand-lg" style="background-color : #6A8CAF">
  <div class="container-fluid">
    <a class="navbar-brand font-weight-bold text-white" href="#slider-part">PUSTULUSA</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse text-end" id="navbarNavAltMarkup">
      <div class="navbar-nav ms-auto">
        <a class="nav-item nav-link text-white " aria-current="page" href="home.php">Home</a>
        <a class="nav-item nav-link text-white" href="#row-part">About</a>
        <a class="nav-item nav-link text-white" href="#category-part">Kategori Buku</a>
        <a class="nav-item nav-link text-white" href="#buku-part">Semua Buku</a> 
         <a class="nav-item nav-link text-white" href="loginmem.php">Area Member</a>
          <a class="nav-item nav-link text-white" href="login2.php">Area Petugas</a>
          <a class="nav-item nav-link text-white" href="login.php">Area Admin</a>
      </div>
    </div>
    </div>
  </div>
   <!-- Slider-->
  
   <div id="carouselExampleIndicators" class="carousel slide" data-bs-ride="carousel">
  <div class="carousel-indicators">
    <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
    <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="1" aria-label="Slide 2"></button>
    <!-- <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="2" aria-label="Slide 3"></button> -->
  </div>
  <div class="carousel-inner " section id="slider-part">
    <div class="carousel-item active">
       <div class="carousel-caption d-none d-md-block">

        <h2> Selamat Datang </h2>
    <h3> Di Website PUSTULUSA</h3>
    <h3>Enjoying Borrow and Searching Our Book</h3>
    <a href="loginmem.php" class="btn btn-primary tombol text uppercase">Join Member</a>
      </div>
      <img src="img/perpus1.jpg" class="d-block w-100" alt="...">
     
    </div>
    <div class="carousel-item">
      <img src="img/baca1.jpg" class="d-block w-100" alt="...">
      <div class="carousel-caption d-none d-md-block">
        <h2> Selamat Datang </h2>
    <h3> Di Website PUSTULUSA</h3>
    <h3>Enjoying Borrow and Searching Our Book</h3>
    <a href="loginmem.php" class="btn btn-primary tombol text uppercase">Join Member</a>
      </div>
  </div>
    <!-- <div class="carousel-item">
      <img src="..." class="d-block w-100" alt="...">
    </div> -->
  </div>
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
   </div>
</div>
</nav>
<div id="search-wrapper"xmlns:v-bind="http://www.w3.org/1999/xhtml" class="search">
<div class="container">
  <div class="row" section id="row-part">
    <div class="col-8 mx-auto">
      <div class="card border-0 shadow">
        <div class="card-body-atas">
          <div class="row"> <h4><img src="img/book2.png"> PUSTULUSA <img src="img/book2.png"></h4>
          <h6>PERPUSTAKAAN SMKN 71 JAKARTA</h6>
      </div>
    </div>
  </div>
</div>
<div class="row about">
  <div class="col">
    <img src="img/perpus2.jpg" alt="about" class="img-fluid">
  </div>
     <div class="col" section id="about-part">
      <h2>About</h2>
      <h4>Pustulusa (E-Library) berbasis Online digunakan untuk mempermudah warga sekolah untuk meminjam dan lihat buku diperpustakaan melalui Online</h4>
</div>
</div>
</div>
</div>
</div>
</div> 

<div id="category"  style="background-color : white;">
<div class="container kategori">
  <h4>BOOK</h4><h3>Kategori Buku</h3>
  <div class="row" section id="category-part">
  <div class="col-md-3">
  <div class="card">
  <div class="card-header text-white bg-dark ">Kategori Buku</div>
  <div class="card-body text-dark bg-light">
    <h5 class="card-title">Pelajaran</h5>
    <p class="card-text">Kategori buku ini berisi buku-buku paket dan/atau yang bersangkutan dengan Pelajaran</p>
  </div>
</div>
</div>
<div class="col-md-3">
  <div class="card">
  <div class="card-header text-white bg-dark ">Kategori Buku</div>
  <div class="card-body text-dark bg-light">
    <h5 class="card-title">Bahasa</h5>
    <p class="card-text">Kategori buku ini berisi buku-buku kamus dan/atau yang bersangkutan dengan Bahasa seperti bahasa daerah, dsb</p>
  </div>
</div>
</div>
<div class="col-md-3">
  <div class="card">
  <div class="card-header text-white bg-dark ">Kategori Buku</div>
  <div class="card-body text-dark bg-light">
    <h5 class="card-title">Olahraga</h5>
    <p class="card-text">Kategori buku ini berisi buku-buku panduan Olahraga dan/atau yang bersangkutan dengan Olahraga</p>
  </div>
</div>
</div>
<div class="col-md-3">
  <div class="card">
  <div class="card-header text-white bg-dark ">Kategori Buku</div>
  <div class="card-body text-dark bg-light">
    <h5 class="card-title">Seni</h5>
    <p class="card-text">Kategori buku ini berisi buku-buku yang bersangkutan dengan seni seperti kunci gitar, gerak tari, dsb</p>
  </div>
</div>
</div>
<div class="row category">
<div class="col-md-3">
  <div class="card">
  <div class="card-header text-white bg-dark ">Kategori Buku</div>
  <div class="card-body text-dark bg-light">
    <h5 class="card-title">Kewirausahaan</h5>
    <p class="card-text">Kategori buku ini berisi buku-buku kewirausahaan apabila ada salah satu warga sekolah yang ingin buka usaha</p>
  </div>
</div>
</div>
<div class="col-md-3">
  <div class="card">
  <div class="card-header text-white bg-dark ">Kategori Buku</div>
  <div class="card-body text-dark bg-light">
    <h5 class="card-title">Novel</h5>
    <p class="card-text">Kategori buku ini berisi Novel terkini pilihan dengan berbagai genre (Romansa, Komedi, Action, Dsb)</p>
  </div>
</div>
</div>
<div class="col-md-3">
  <div class="card">
  <div class="card-header text-white bg-dark ">Kategori Buku</div>
  <div class="card-body text-dark bg-light">
    <h5 class="card-title">Agama</h5>
    <p class="card-text">Kategori buku ini berisi buku-buku tentang keagaamaan, seperti Al-Qur'an, Alkitab, Tafsir, dsb</p>
  </div>
</div>
</div>
</div>
</div>
</div>
<div id="book" style="background-color : #B9D1DC;">
<div class="container buku">
  <h3>BOOK</h3><h2>Semua Buku </h2>
  <div class="row section" id="buku-part">
    <div class="col-md-3">
      <div class="card ">
  <img src="img/olahraga_kamus.jpg" class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title"><b>Kamus Basket</b></h5>
  <p class="card-text">Sajian kata/bahasa yang digunakan dalam olahraga basket.</p>
  </div>
</div>
    </div>
    <div class="col-md-3">
      <div class="card ">
  <img src="img/simdig_paket.jpg" class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title"><b>Buku SimDig</b></h5>
  <p class="card-text">Buku Paket Simulasi Digital kelas X</p>
  </div>
</div>
  </div>
  <div class="col-md-3">
      <div class="card ">
  <img src="img/novel_geez.jpg" class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title"><b> Novel Gezz And Ann</b></h5>
  <p class="card-text">Novel yang berkisah cinta remaja dengan genre Fiksi Romansa</p>
  </div>
</div>
</div>
<div class="col-md-3">
      <div class="card ">
  <img src="img/usbnn.jpg" class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title"><b>BUKU ERLANGGA XPRESS US SMK MATEMATIKA</b></h5>
  <p class="card-text">Buku LATSOL USBN Matematika SMK</p>
  </div>
</div>
</div>
</div>

<div class="row book">
<div class="col-md-3">
      <div class="card ">
  <img src="img/paket_rpl.jpg" class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title"><b>Pemrograman Web</b></h5>
  <p class="card-text"> Buku Paket Pemweb Program Keahlian TIK Kompetensi RPL SMK Kelas 12 </p>
  </div>
</div>
</div>
<div class="col-md-3">
      <div class="card ">
  <img src="img/kata_novel.jpg" class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title"><b>Novel Kata</b></h5>
  <p class="card-text">Novel yang berkisah cinta remaja dengan genre Fiksi Romansa</p>
  </div>
</div>
</div>
<div class="col-md-3">
      <div class="card ">
  <img src="img/kamus.jpg" class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title"><b>Kamus Bahasa Inggris</b></h5>
  <p class="card-text">Buku kamus indonesia-inggris untuk mencari kata sulit pada bahasa inggris</p>
  </div>
</div>
</div> 
</div>
</div>
</div>
<div class="footer">
            <div class="footer-list">
                <p> &copy; Copyright 2022 - Website Pustulusa </p>
        </div>
        </div>     
</div>
    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js" integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js" integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" crossorigin="anonymous"></script>
    -->
  </body>
</html>