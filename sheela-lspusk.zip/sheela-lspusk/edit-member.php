<?php

session_start();

$conn = mysqli_connect("localhost", "root", "", "pra_lsp");

//if (!isset($_SESSION["login"])) {
  //header("location: login.php");
  //exit;
//}
// if ($_SESSION["jabatan"]=="pengguna") {
//   header("location: index.php");
//   exit;
// }
require 'functions.php';

$petugas = mysqli_query($conn, "SELECT * FROM petugas WHERE idpetugas  ='$_SESSION[idpetugas]'");
$name = mysqli_fetch_array($petugas);


// // mengambil data barang
$tampilpeg = mysqli_query($conn, "SELECT * FROM member");

// ambil data di URL
$idmember = $_GET["idmember"];

// untuk mengubah data
if (isset($_POST["ubah_member"])) {
    if (ubah_member ($_POST) > 0 ) {
      echo " 
      <script>
      alert ('data berhasil diubah');
      document.location.href = 'data-member.php';
      </script> ";
  } else {
    echo "
    <script>
    alert ('data gagal diubah');
    document.location.href = 'data-member.php';
    </script>";
}
}
if (!$conn) {
    die ("Koneksi gagal. " . mysqli_connect_error()); // close koneksi
}
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta name="description" content="Vali is a responsive and free admin theme built with Bootstrap 4, SASS and PUG.js. It's fully customizable and modular.">
    <!-- Twitter meta-->
    <meta property="twitter:card" content="summary_large_image">
    <meta property="twitter:site" content="@pratikborsadiya">
    <meta property="twitter:creator" content="@pratikborsadiya">
    <!-- Open Graph Meta-->
    <meta property="og:type" content="website">
    <meta property="og:site_name" content="Vali Admin">
    <meta property="og:title" content="Vali - Free Bootstrap 4 admin theme">
    <meta property="og:url" content="http://pratikborsadiya.in/blog/vali-admin">
    <meta property="og:image" content="http://pratikborsadiya.in/blog/vali-admin/hero-social.png">
    <meta property="og:description" content="Vali is a responsive and free admin theme built with Bootstrap 4, SASS and PUG.js. It's fully customizable and modular.">
    <title>Account-Pustulusa Admin</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Main CSS-->
    <link rel="stylesheet" type="text/css" href="css/main.css">
    <!-- Font-icon css-->
    <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  </head>
  <body class="app sidebar-mini rtl">
    <!-- Navbar-->
    <header class="app-header"><a class="app-header__logo" href="index.php">PUSTULUSA</a>
      <!-- Sidebar toggle button--><a class="app-sidebar__toggle" href="#" data-toggle="sidebar" aria-label="Hide Sidebar"></a>
      <!-- Navbar Right Menu-->
      <ul class="app-nav">
        <li class="app-search">
          <input class="app-search__input" type="search" placeholder="Search">
          <button class="app-search__button"><i class="fa fa-search"></i></button>
        </li>
        <!--Notification Menu-->
        <!-- User Menu-->
        <li class="dropdown"><a class="app-nav__item" href="#" data-toggle="dropdown" aria-label="Open Profile Menu"><i class="fa fa-user fa-lg"></i></a>
          <ul class="dropdown-menu settings-menu dropdown-menu-right">
            <li><a class="dropdown-item" href="setting.php"><i class="fa fa-user fa-lg"></i> Profile</a></li>
            <li><a class="dropdown-item" href="logout.php"><i class="fa fa-sign-out fa-lg"></i> Logout</a></li>
          </ul>
        </li>
      </ul>
    </header>
    <!-- Sidebar menu-->
    <div class="app-sidebar__overlay" data-toggle="sidebar"></div>
    <aside class="app-sidebar">
      <div class="app-sidebar__user"><img class="app-sidebar__user-avatar" src="img/logoo.png" alt="User Image">
        <div>
          <p class="app-sidebar__user-name"><?php echo $name['nama_petugas']; ?></p>
          <p class="text-muted m-0">Administrator</p>
        </div>
      </div>
      <ul class="app-menu">
         <li><a class="app-menu__item" href="index.php"><i class="app-menu__icon fa fa-dashboard"></i><span class="app-menu__label">Dashboard</span></a></li>
         <li class="treeview"><a class="app-menu__item" href="#" data-toggle="treeview"><i class="app-menu__icon fa fa-th-list"></i><span class="app-menu__label">Data</span><i class="treeview-indicator fa fa-angle-right"></i></a>
          <ul class="treeview-menu">
            <li><a class="treeview-item" href="data-member.php"><i class="icon fa fa-circle-o"></i> Data Member</a></li>
            <li><a class="treeview-item" href="data-admin.php"><i class="icon fa fa-circle-o"></i> Data Petugas</a></li>
          </ul>
        </li>
         <li class="treeview"><a class="app-menu__item" href="#" data-toggle="treeview"><i class="app-menu__icon fa fa-book"></i><span class="app-menu__label">Buku</span><i class="treeview-indicator fa fa-angle-right"></i></a>
          <ul class="treeview-menu">
            <li><a class="treeview-item" href="data-buku.php"><i class="icon fa fa-circle-o"></i> Data Buku</a>
            <li><a class="treeview-item" href="kategori-buku.php"><i class="icon fa fa-circle-o"></i> Kategori Buku</a></li>
          </ul>
        </li>
        <li class="treeview"><a class="app-menu__item" href="#" data-toggle="treeview"><i class="app-menu__icon fa fa-edit"></i><span class="app-menu__label">Pinjam & Kembali</span><i class="treeview-indicator fa fa-angle-right"></i></a>
          <ul class="treeview-menu">
            <li><a class="treeview-item" href="data-peminjaman.php"><i class="icon fa fa-circle-o"></i> Data Peminjaman</a></li>
            <li><a class="treeview-item" href="data-pengembalian.php"><i class="icon fa fa-circle-o"></i> Data Pengembalian</a></li>
          </ul>
        </li>
       <!--<li class="treeview"><a class="app-menu__item" href="#" data-toggle="treeview"><i class="app-menu__icon fa fa-sign-in"></i><span class="app-menu__label">Register & Login</span><i class="treeview-indicator fa fa-angle-right"></i></a>
          <ul class="treeview-menu">
            <li><a class="treeview-item" href="daftar.php"><i class="icon fa fa-circle-o"></i> Register</a></li>
            <li><a class="treeview-item" href="login.php"><i class="icon fa fa-circle-o"></i> Login</a></li>-->
            
           
          </ul>
        </li>
      </ul>
    </aside>
    <main class="app-content">
      <div class="app-title">
        <div>
          <h1><i class="fa fa-user-circle"></i>  EDIT MEMBER</h1>
          <p>Edit Member Website PUSTULUSA</p>
        </div>
        <ul class="app-breadcrumb breadcrumb side">
          <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
          <li class="breadcrumb-item active"><a href="#"> Profile</a></li>
        </ul>
      </div>
      <div class="row">
       
      <div class="col-md-12">
          <div class="bs-component">
                <h4 class="card-header"><i class="fa fa-user-plus" aria-hidden="true"></i> Data Member</h4>
          <div class="tile">
            <div class="tile-body">
              <table class="table table-hover table-bordered" id="sampleTable">
                        <?php
                        $tampilPeg = mysqli_query($conn, "SELECT * FROM member WHERE idmember  ='$idmember'");
                        $dt = mysqli_fetch_array($tampilPeg);
                        $no = 0;
                        ?>
                        <div class="card-body">
                            <div class="table-responsive">
                                <form method="POST">
                                    <input type="hidden" name="idmember" value=<?php echo $_GET['idmember'];?>>
                                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                        <thead align="center">
                                            <tr>
                                                <th>ID</th>
                                                <th>Nama Member</th>
                                                <th>Tempat Lahir</th>
                                                <th>Tanggal Lahir</th>
                                                <th>Alamat</th>
                                            </tr>
                                        </thead>
                                        <tbody align="center">
                                            <tr>
                                                <td><?= $dt["idmember"]; ?></td> 
                                                <td><input type="text" name="nama_member" value="<?= $dt['nama_member']; ?>"></td>
                                                <td><input type="text" name="tempat_lahir" value="<?= $dt['tempat_lahir']; ?>"></td>
                                                <td><input type="date" name="tgl_lahir" value="<?= $dt['tgl_lahir']; ?>"></td>
                                                <td><textarea style="height: 105px;" name="alamat"><?= $dt['alamat']; ?></textarea></td>
                                            </tr> 
                                        </tbody>
                                    </table>
                                    <button type="submit" name="ubah_member" class="btn btn-success btn-sm">Update</button>&emsp;
                                    <a href="data-member.php"><span class="btn btn-danger btn-sm">Back</span></a>
                                </form>
                            </div>
                        </div>
        </div>
      </form>
    </div>
  </div>
    <!-- Essential javascripts for application to work-->
    <script src="js/jquery-3.2.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/main.js"></script>
    <!-- The javascript plugin to display page loading on top-->
    <script src="js/plugins/pace.min.js"></script>
    <!-- Page specific javascripts-->
    <!-- Data table plugin-->
    <script type="text/javascript" src="js/plugins/jquery.dataTables.min.js"></script>
    <script type="text/javascript" src="js/plugins/dataTables.bootstrap.min.js"></script>
    <script type="text/javascript">$('#sampleTable').DataTable();</script>
    <!-- Google analytics script-->
    <script src="js/jquery-3.2.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/main.js"></script>
    <!-- The javascript plugin to display page loading on top-->
    <script src="js/plugins/pace.min.js"></script>
    <!-- Page specific javascripts-->
    <!-- Data table plugin-->
    <script type="text/javascript" src="js/plugins/jquery.dataTables.min.js"></script>
    <script type="text/javascript" src="js/plugins/dataTables.bootstrap.min.js"></script>
    <script type="text/javascript">$('#sampleTable').DataTable();</script>
    <!-- Google analytics script-->
    <script type="text/javascript">
      if(document.location.hostname == 'pratikborsadiya.in') {
        (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
        (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
        m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
        })(window,document,'script','//www.google-analytics.com/analytics.js','ga');
        ga('create', 'UA-72504830-1', 'auto');
        ga('send', 'pageview');
      }
    </script>
  </body>
</html>